import sys
import subprocess
import ast
from collections import namedtuple

def queens(n):
    print("n-queens", n)


