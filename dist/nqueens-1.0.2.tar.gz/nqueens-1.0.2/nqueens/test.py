from code import *


# Test code

qq = Queen(5, "backtrack")
qq.pprint()

qq = Queen(algo = "backtrack")
qq.pprint()

qq = Queen(algo = "backtrack")
qq.scan_queen("q4.png")
qq.pprint()

qq = Queen(algo = "backtrack")
qq.scan_queen("q4.png")
qq.pprint()
qq.alexa()

qq = Queen(algo = "backtrack")
qq.scan_queen("q6.png")
qq.pprint()
qq.display()

qq = Queen(algo = "backtrack")
qq.scan_queen("q6.png")
qq.save()